using UnityEngine;

public class TechtonicsController : MonoBehaviour
{
    public GameObject[,] TilePlate;
    public GameObject[,] TileVert;
    public GameObject[,] TileEdgeX;
    public GameObject[,] TileEdgeY;

    public GameObject Selected;
    Spawner spawner;

    void Awake()
    {
        spawner = GetComponent<Spawner>();
    }

    public void InitialisePlates(GameObject[,] TilePlateIn, GameObject[,] TileVertIn, GameObject[,] TileEdgeXIn, GameObject[,] TileEdgeYIn)
    {
        TilePlate = TilePlateIn;
        TileVert = TileVertIn;
        TileEdgeX = TileEdgeXIn;
        TileEdgeY = TileEdgeYIn;
    }

    public GameObject NorthOfSelected;
    public GameObject SouthOfSelected;
    public GameObject EastOfSelected;
    public GameObject WestOfSelected;

    public void DetermineCollide(Vector3 vector3)
    {
        EastOfSelected = TileEdgeX[(int)Selected.GetComponent<PlateData>().SnappedCoord.x + (int)(spawner.Size.x / 2), (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)(spawner.Size.y / 2)];
        WestOfSelected = TileEdgeX[(int)Selected.GetComponent<PlateData>().SnappedCoord.x + (int)(spawner.Size.x / 2) - 1, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)(spawner.Size.y / 2)];
        NorthOfSelected = TileEdgeY[(int)Selected.GetComponent<PlateData>().SnappedCoord.x + (int)(spawner.Size.x / 2), (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)(spawner.Size.y / 2)];
        SouthOfSelected = TileEdgeY[(int)Selected.GetComponent<PlateData>().SnappedCoord.x + (int)(spawner.Size.x / 2), (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)(spawner.Size.y / 2) - 1];

        if (vector3.x != 0)
        {
            if (vector3.x == 1)
            {
                //East
                EastOfSelected.GetComponent<PlateData>().PlateConverge(Selected);
                WestOfSelected.GetComponent<PlateData>().PlateDiverge(Selected);
                NorthOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
                SouthOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
            }
            else
            {
                //West
                WestOfSelected.GetComponent<PlateData>().PlateConverge(Selected);
                EastOfSelected.GetComponent<PlateData>().PlateDiverge(Selected);
                NorthOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
                SouthOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
            }
        }
        else
        {
            if (vector3.z == 1)
            {
                //North
                NorthOfSelected.GetComponent<PlateData>().PlateConverge(Selected);
                SouthOfSelected.GetComponent<PlateData>().PlateDiverge(Selected);
                EastOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
                WestOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
            }
            else
            {
                //South
                SouthOfSelected.GetComponent<PlateData>().PlateConverge(Selected);
                NorthOfSelected.GetComponent<PlateData>().PlateDiverge(Selected);
                EastOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
                WestOfSelected.GetComponent<PlateData>().PlateGraze(Selected);
            }
        }
    }
}