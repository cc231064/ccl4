using UnityEngine;

public class PlateData : MonoBehaviour
{
    public string PlateType;
}