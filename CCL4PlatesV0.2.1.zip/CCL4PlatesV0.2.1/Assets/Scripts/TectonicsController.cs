using Unity.Mathematics;
using UnityEngine;

public class TechtonicsController : MonoBehaviour
{
    public GameObject[,] TilePlate;
    public GameObject[,] TileVert;
    public GameObject[,] TileEdgeX;
    public GameObject[,] TileEdgeY;

    public GameObject Selected;
    Spawner spawner;

    void Awake()
    {
        spawner = GetComponent<Spawner>();
    }

    public void InitialisePlates(GameObject[,] TilePlateIn, GameObject[,] TileVertIn, GameObject[,] TileEdgeXIn, GameObject[,] TileEdgeYIn)
    {
        TilePlate = TilePlateIn;
        TileVert = TileVertIn;
        TileEdgeX = TileEdgeXIn;
        TileEdgeX = TileEdgeYIn;
    }

    public void DetermineCollide(Vector3 vector3)
    {
        if (Selected.GetComponent<PlateData>().PlateType == "Land")
        {
            if (math.abs(vector3.x) > 0)
            {
                if (vector3.x < 0)
                {
                    //LDown
                    if (!(((int)Selected.GetComponent<PlateData>().SnappedCoord.x) + (int)spawner.Size.x / 2 < 1))
                    {
                        if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Land")
                        {
                            Debug.Log("Land Collision");
                            LtLcollide(Selected, spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2]);
                        }
                        else if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Ocean")
                        {
                            Debug.Log("Ocean Collision");
                        }
                    }
                }
                else
                {
                    //RUp
                    if (!(((int)Selected.GetComponent<PlateData>().SnappedCoord.x) + (int)spawner.Size.x / 2 > (int)spawner.Size.x - 2))
                    {
                        if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) + 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Land")
                        {
                            Debug.Log("Land Collision");
                        }
                        if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) + 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Ocean")
                        {
                            Debug.Log("Ocean Collision");
                        }
                    }
                }
            }
            else
            {
                if (vector3.z < 0)
                {
                    //RDown
                    if (!(((int)Selected.GetComponent<PlateData>().SnappedCoord.z) + (int)spawner.Size.y / 2 < 1))
                    {
                        if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Land")
                        {

                        }
                        else if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Ocean")
                        {

                        }
                    }
                }
                else
                {
                    //LUp
                    if (!(((int)Selected.GetComponent<PlateData>().SnappedCoord.z) + (int)spawner.Size.y / 2 < 1))
                    {
                        if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Land")
                        {

                        }
                        else if (spawner.TilePlate[((int)Selected.GetComponent<PlateData>().SnappedCoord.x) - 1 + (int)spawner.Size.x / 2, (int)Selected.GetComponent<PlateData>().SnappedCoord.z + (int)spawner.Size.y / 2].GetComponent<PlateData>().PlateType == "Ocean")
                        {

                        }
                    }
                }
            }
        }        
    }

    public void LtLcollide(GameObject from, GameObject into)
    {
        Debug.Log("Land Collision");
    }

    public void LtLDrift()
    {

    }

    public void LtLSeperate()
    {

    }

    public void OtLcollide()
    {

    }

    public void OtLDrift()
    {

    }

    public void OtLSeperate()
    {

    }
    
    public void OtOcollide()
    {

    }

    public void OtODrift()
    {

    }

    public void OtOSeperate()
    {

    }
}